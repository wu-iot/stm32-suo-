#ifndef   _BKP_H
#define   _BKP_H

#include "stm32f10x.h"
void Load_Password(void);	
void WritePasswordToBackupReg(uint16_t passwordarray[]);


#endif


