#ifndef __BSP_UART_H
#define __BSP_UART_H

#include "stm32f10x.h"
#include "stdio.h"

	

//TX,RX�ܽų�ʼ���йغ궨��
#define UART_TX_GPIO_CLOCK	RCC_APB2Periph_GPIOA
#define UART_TX_GPIO_PIN    GPIO_Pin_9
#define UART_TX_GPIO_PORT   GPIOA

#define UART_RX_GPIO_CLOCK	RCC_APB2Periph_GPIOA
#define UART_RX_GPIO_PIN    GPIO_Pin_10
#define UART_RX_GPIO_PORT   GPIOA

//uart��ʼ���йغ궨��
#define UART_BAUDRATE				115200
#define UART_PORT    				USART1
#define UART_CLOCK					RCC_APB2Periph_USART1

void uart_GPIO_Config(void);
void	UART_Sendbyte(USART_TypeDef* USART, uint16_t ch);
void UART_SendString(USART_TypeDef* USART, char* str);
void uart3_GPIO_Config(void);



#endif   // __BSP_UART_H0

