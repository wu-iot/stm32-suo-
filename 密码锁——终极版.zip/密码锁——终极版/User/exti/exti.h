#ifndef   _EXTI_H
#define   _EXTI_H

#include "stm32f10x.h"
		 
void EXTI_Configuration(void);
void NVIC_Configuration(void);

#endif


