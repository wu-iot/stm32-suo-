#ifndef   _KEY_H
#define   _KEY_H

#include "stm32f10x.h"
		 
void RCC_Configuration(void);
void GPIO_Configuration(void);
void KeyBoard_Config(void);
void KeyBoard_Conv(uint16_t GPIO_Pin);
void ZD_Init(void);
void ZL_Init(void);

#endif

