/**
  ******************************************************************************
  * �ļ����ƣ�stm32f10x_it.c 
  * �жϷ������
  */ 

#include "stm32f10x_it.h"
#include "bsp_uart.h"
// ������̽ӿ�����
extern void KeyBoard_Config(void);
// ����ת��Ϊ��������
extern void KeyBoard_Conv(uint16_t GPIO_Pin);

__IO uint16_t keyval  = 0;
__IO uint16_t keyflag = 0;

//��ʱn us
void delay_nus1(unsigned long n)
{
	unsigned long j;
	while(n--)
	{ j=15;
	  while(j--);
	}
}
//��ʱn ms
void delay_nms1(unsigned long n)
{
	while(n--)
	   delay_nus1(1075);
}

// PE.0 ����0�ж�
void EXTI0_IRQHandler(void)
{
	
	uint16_t keycol;
	//printf("�ж�\r\n");
	if(EXTI_GetITStatus(EXTI_Line0)!=RESET)
	{
		//printf("��һ���ж�\r\n");
		KeyBoard_Conv(GPIO_Pin_0);
		GPIO_ResetBits(GPIOE,GPIO_Pin_0);
		delay_nms1(1);
		keycol = GPIO_ReadInputData(GPIOE)&0x00f0;
		if(keycol)
		{
			delay_nms1(8);
			if(keycol == (GPIO_ReadInputData(GPIOE)& 0x00f0))
			{
			    keyflag = 1;
				switch(keycol)
				{
					case 0xE0: keyval = 1;  break;
					//case 0xD0: keyval = 2;  break;
					case 0xB0: keyval = 2;  break;
					case 0x70: keyval = 3;break;
				}
			}
		}
		printf("%c",keyval+'0');
		KeyBoard_Config();
		EXTI_ClearITPendingBit(EXTI_Line0);
	}
}

// PE.1 ����1�ж�
void EXTI1_IRQHandler(void)
{
	uint16_t keycol;
	if(EXTI_GetITStatus(EXTI_Line1)!=RESET)
	{
		//printf("�ڶ����ж�\r\n");
		KeyBoard_Conv(GPIO_Pin_1);
		GPIO_ResetBits(GPIOE,GPIO_Pin_1);
		delay_nms1(1);
		keycol = GPIO_ReadInputData(GPIOE)&0x00f0;
		if(keycol)
		{
			delay_nms1(8);
			if(keycol == (GPIO_ReadInputData(GPIOE)& 0x00f0))
			{ 
			    keyflag = 1;
				switch(keycol)
				{
					case 0xE0: keyval = 4;  break;
					//case 0xD0: keyval = 5;  break;
					case 0xB0: keyval = 5;  break;
					case 0x70: keyval = 6;break;
				}
			}
		}
		printf("%c",keyval+'0');
		KeyBoard_Config();
		EXTI_ClearITPendingBit(EXTI_Line1);
	}
}

// PE.2 ����2�ж�
void EXTI2_IRQHandler(void)
{
	uint16_t keycol;
	if(EXTI_GetITStatus(EXTI_Line2)!=RESET)
	{
		//printf("�������ж�\r\n");
		KeyBoard_Conv(GPIO_Pin_2);
		GPIO_ResetBits(GPIOE,GPIO_Pin_2);
		delay_nms1(1);
		keycol = GPIO_ReadInputData(GPIOE)&0x00f0;
		if(keycol)
		{
			delay_nms1(8);
			if(keycol == (GPIO_ReadInputData(GPIOE)& 0x00f0))
			{
				keyflag = 1;
				switch(keycol)
				{
					case 0xE0: keyval = 7;  break;
					//case 0xD0: keyval = 8;  break;
					case 0xB0: keyval = 8;  break;
					case 0x70: keyval = 9;break;
				}
			}
		}
		printf("%c",keyval+'0');
		KeyBoard_Config();
		EXTI_ClearITPendingBit(EXTI_Line2);
	}
}

// PE.3 ����3�ж�
void EXTI3_IRQHandler(void)
{
	uint16_t keycol;
	if(EXTI_GetITStatus(EXTI_Line3)!=RESET)
	{
		//printf("�������ж�\r\n");
		KeyBoard_Conv(GPIO_Pin_3);
		GPIO_ResetBits(GPIOE,GPIO_Pin_3);
		delay_nms1(1);
		keycol = GPIO_ReadInputData(GPIOE)&0x00f0;
		if(keycol)
		{
			delay_nms1(8);
			if(keycol == (GPIO_ReadInputData(GPIOE)& 0x00f0))
			{
				keyflag = 1;
				switch(keycol)
				{
					case 0xE0: keyval = 'c';break;
					//case 0xD0: keyval = 'p';  break;
					case 0xB0: keyval = 'p';break;
					case 0x70: keyval = 'e';break;
				}
			}
		}
		printf("%c\r\n",keyval);
		KeyBoard_Config();
		EXTI_ClearITPendingBit(EXTI_Line3);
	}
}




/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief   This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
